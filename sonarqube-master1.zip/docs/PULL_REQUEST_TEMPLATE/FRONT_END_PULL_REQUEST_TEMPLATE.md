**Checklist**

* [ ] Write/update ITs
* [ ] Functional validation
* [ ] Public documentation update
* [ ] Private documentation update
* [ ] Run accessibility audit using [Chrome's Lighthouse](https://developers.google.com/web/tools/lighthouse/)
* [ ] Ping a member of the other team (SQ/SC)
